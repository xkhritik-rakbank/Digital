/*
---------------------------------------------------------------------------------------------------------
                  NEWGEN SOFTWARE TECHNOLOGIES LIMITED

Group                   : Application - Projects
Project/Product			: CAS
Application				: FALCON Document Attach Utility
Module					: FALCON Document
File Name				: FalconDocumentLog.java
Author 					: Sajan
Date (DD/MM/YYYY)		: 05/12/2019

---------------------------------------------------------------------------------------------------------
                 	CHANGE HISTORY
---------------------------------------------------------------------------------------------------------

Problem No/CR No        Change Date           Changed By             Change Description
---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
*/


package com.newgen.DigitalCC.Dispatch;

import java.util.HashMap;
import java.util.Map;

public class DCCWorkItem
{
	public String processInstanceId;
	public String workItemId;
	@SuppressWarnings("unchecked")
	public Map map = new HashMap();

	public String getAttribute(String attributeName)
	{
		return (String)map.get(attributeName);
	}
}
